(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_567cf1c0._.js",
  "static/chunks/_d5cc0cfa._.js"
],
    source: "dynamic"
});
