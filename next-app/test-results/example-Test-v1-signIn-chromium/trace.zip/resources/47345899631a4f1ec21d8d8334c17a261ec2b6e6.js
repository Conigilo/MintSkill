(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/lib/services/endorsements.service.ts [app-client] (ecmascript, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.resolve().then(() => {
        return parentImport("[project]/lib/services/endorsements.service.ts [app-client] (ecmascript)");
    });
});
}),
"[project]/node_modules/react-activity-calendar/build/chunks/Tooltip-B8gZJWmn.js [app-client] (ecmascript, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "static/chunks/node_modules_7998ba12._.js",
  "static/chunks/node_modules_react-activity-calendar_build_chunks_Tooltip-B8gZJWmn_73c92f1a.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/node_modules/react-activity-calendar/build/chunks/Tooltip-B8gZJWmn.js [app-client] (ecmascript)");
    });
});
}),
]);