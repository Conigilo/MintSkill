(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/_7338fc7a._.js",
  "static/chunks/_6d76eb88._.js",
  "static/chunks/node_modules_eb8df297._.js"
],
    source: "dynamic"
});
